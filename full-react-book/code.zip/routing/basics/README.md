# Routing basics

This app is powered by create-react-app.

## Running

Install dependencies:

```
npm i
```

Boot:

```
npm start
```

The app will be available at `http://localhost:3000`